# Tint Conditions Booking — standalone MVP source

This is an **actual self-hostable application**, not a mockup. It has a FastAPI backend, SQLite database, branded booking pages and a password-protected owner dashboard. It has NOT been deployed, live-tested against Square/Twilio or approved for production.

## Features
- Three films: Entry Level, Standard Ceramic and Premium Ceramic
- Six appointment services, with configurable dollar prices and duration (base service durations are in `SERVICES`)
- Shop hours Monday–Friday 8:30 AM–6 PM Central by default; owner can change hours and block dates
- Real-time availability, 35-minute temporary reservation holds, conflict checks under SQLite `BEGIN IMMEDIATE`
- Deposit-required booking, Square Checkout redirect and signed webhook confirmation (never trust a success URL alone)
- Customer self-service rescheduling with private token, at least 24 hours before appointment
- Owner dashboard: bookings, statuses, schedule blocks, hours, prices, deposit amount, discount codes, and gift certificate codes
- SMS reminder job with Twilio (opt-in required), sends around 24 hours before the visit
- Promo codes and gift certificate balances

## Run locally
1. Install Python 3.11+.
2. `cd tint_conditions_system`
3. `python -m venv .venv` and activate it.
4. `pip install -r requirements.txt`
5. `cp .env.example .env` and fill in passwords and private API credentials. **Never expose the .env file publicly.**
6. `uvicorn app:app --reload --host 127.0.0.1 --port 8000`
7. Customer booking: `http://localhost:8000/`
8. Owner login: `http://localhost:8000/owner` (browser prompts for HTTP Basic auth)

## Square setup (required for paid deposits)
1. Go to [Square Developer](https://developer.squareup.com/apps) and create an application in your own Square seller account.
2. In **Sandbox**, copy the access token and Location ID into `SQUARE_ACCESS_TOKEN` and `SQUARE_LOCATION_ID`. Set `SQUARE_ENVIRONMENT=sandbox`.
3. Under Webhooks, create a subscription to **payment.created** and **payment.updated** at `https://YOUR-DOMAIN/api/square/webhook`; paste the signature key into `SQUARE_WEBHOOK_SIGNATURE_KEY`. Set `SQUARE_WEBHOOK_URL` to the EXACT webhook URL configured in Square. It must be public HTTPS.
4. Set `APP_BASE_URL=https://YOUR-DOMAIN`.
5. Test a full booking using Square sandbox checkout; **returning to the site is not proof of payment**. Only a verified webhook with a completed payment, matching Square order ID, location ID, currency and deposit amount will confirm a booking.
6. For production, change `SQUARE_ENVIRONMENT=production`, use your production access token and location ID, and create a production webhook subscription and signing key. Do not reuse sandbox credentials.
7. Square Checkout may charge transaction fees. Keep access tokens and webhook signing keys on the server only.

**Important:** A failed webhook delivery or successful late payment can require reconciliation. This MVP does not implement automatic refunds, reconciliation polling, gift-card reservation concurrency, or full production authentication. Never use it for live bookings without additional security and payment testing.

## Twilio reminders
Configure the SID, token, and sender phone number in `.env`. Set `REMINDER_SECRET`. Set a scheduled task (cron or hosting cron) to POST `/api/jobs/reminders` hourly with header `X-Reminder-Secret: YOUR_SECRET`. Only opted-in customers get reminders, and successful sends are marked as sent. Configure STOP/HELP opt-out handling with your sender and comply with messaging registration rules.

## Architecture
```
Customer browser -> FastAPI -> SQLite (owner-managed schedules / codes / appointments)
                           -> Square Checkout -> signed webhook -> confirmation
Hourly secure cron -> FastAPI -> Twilio messaging API
Owner browser (password protected) -> FastAPI -> SQLite
```

## Production release checklist (important)
- Domain, HTTPS reverse proxy, dedicated secret environment variables, protected server, backups, monitoring, and log retention
- Replace HTTP Basic with production admin authentication and add rate limits, request throttles, CSRF protection on owner actions, access logs and audit workflows
- Replace publicly viewable reschedule URLs with emailed one-time links, and use mail delivery for confirmations/updates
- Enforce coupon/gift balance reservation at checkout time to avoid overspending by parallel customers; test all refund/cancellation workflows
- Verify pricing, durations, maximum vehicle sizes, taxes, deposit policy and cancellation policy with business owner
- Handle expired/paid late payment, webhook retries, Square Checkout cancellations, and payment conflict/refund escalation
- Add messaging opt-out and delivery-status webhook integration, and schedule missed reminder retry logic
- Add administrative deletion/data retention and consent/privacy policy
- Correct mobile browser date behavior and thoroughly regression test daylight saving transitions
- Consider managed Postgres for multi-instance deployment (SQLite requires one shared server/database volume)

## Pricing assumptions
These defaults are editable placeholders drawn from prior Tint Conditions discussions, NOT a verified 2027 price list:
- Entry: full $250, front two $100, windshield $150, brow $50, standard sunroof $50, panoramic $100
- Standard ceramic: full $340, front two $160, windshield $200, brow $60, standard $80, panoramic $160
- Premium ceramic: full $600, front two $200, windshield $300, brow $60, standard $100, panoramic $200
- Deposit default: $50 (owner can change it).

**No actual bookings, payments, texts or public site exist until you deploy the server and connect provider accounts.**
